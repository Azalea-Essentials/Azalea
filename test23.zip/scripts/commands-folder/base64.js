import { CommandBuilder } from "../commandBuilder";
import LZString from "../lz-string";
export default function () {
  new CommandBuilder("base64-encode").category("Why").desc("AAAAAAAAAAAAAAAAAAAAA").callback(({
    msg,
    args,
    response
  }) => {
    return response(`TEXT ${LZString.compressToBase64(args.join(' '))}`);
  });
}