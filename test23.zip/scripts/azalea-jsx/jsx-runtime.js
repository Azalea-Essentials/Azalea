export function _jsx(Name, Props) {
  return {
    Name,
    Props
  };
}
export function _jsxs(Name, {
  children
}) {
  return {
    Name,
    Children: children
  };
}