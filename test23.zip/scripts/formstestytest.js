import { jsx as _jsx } from "azalea-jsx/jsx-runtime";
let a = _jsx(Form, {
  type: "modal",
  title: "Modal Form",
  children: _jsx(Input, {
    defaultValue: "A",
    placeholder: "B",
    label: "Input"
  }, "input")
});