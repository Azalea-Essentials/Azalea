import { ConfiguratorSub } from "../configuratorOptions";
import { DynamicPropertyDatabase } from "../dynamicPropertyDb";
import { ActionForm, ModalForm } from "../form_func";
import { uiManager } from "../uis";
export default function () {
  let modalForms = new DynamicPropertyDatabase("Modals");
  uiManager.addUI("Azalea2.2/ModalFormEditor/Root/Edit", (player, index) => {
    let actionForm = new ActionForm();
    let forms = modalForms.get("forms", []);
    actionForm.title(forms[index].title);
    actionForm.button(`§cDelete\n§7Deletes the form`, `textures/azalea_icons/Delete`, player => {});
    actionForm.button(`§eEdit Controls\n§7Yes`, `textures/azalea_icons/Pencil`, player => {});
    actionForm.show(player, false, (player, response) => {});
  });
  uiManager.addUI("Azalea2.2/ModalFormEditor/Root/Add", player => {
    let modal = new ModalForm();
    modal.title("Create Modal Form");
    modal.textField("Title", "My Form");
    modal.textField("Tag", "my_form");
    modal.toggle("Force Light Mode", false);
    modal.show(player, false, (player, response) => {
      if (!response.formValues[0] || !response.formValues[1]) return uiManager.open("Azalea2.2/ModalFormEditor/Root", player);
      let forms = modalForms.get("forms", []);
      forms.push({
        title: response.formValues[0],
        tag: response.formValues[1],
        forceLight: response.formValues[2],
        controls: []
      });
      modalForms.set("forms", forms);
      return uiManager.open("Azalea2.2/ModalFormEditor/Root", player);
    });
  });
  uiManager.addUI("Azalea2.2/ModalFormEditor/Root", player => {
    let forms = modalForms.get("forms", []);
    let actionForm = new ActionForm();
    actionForm.button("§eNew Form\n§7Creates a modal form.", `textures/azalea_icons/GUIMaker/Modals/AddModalForm`, player => {
      uiManager.open("Azalea2.2/ModalFormEditor/Root/Add", player);
    });
    for (const form of forms) {
      actionForm.button(`§6${form.title}\n§7${form.tag}`, `textures/azalea_icons/GUIMaker/ModalForm`, player => {});
    }
    actionForm.show(player, false, (player, response) => {});
  });
  return new ConfiguratorSub("Modal Forms", "textures/azalea_icons/GUIMaker/ModalForm").setCallback(player => {
    uiManager.open("Azalea2.2/ModalFormEditor/Root", player);
  });
}