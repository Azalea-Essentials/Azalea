import { ConfiguratorSub } from "../configuratorOptions";
export default function () {
  return new ConfiguratorSub("Modal Forms", "textures/azalea_icons/GUIMaker/ModalForm").setCallback(player => {});
}