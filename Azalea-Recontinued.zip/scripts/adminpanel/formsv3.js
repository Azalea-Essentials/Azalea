import { ConfiguratorSub } from "../configuratorOptions";
export default function () {
  return new ConfiguratorSub("§g§l§o§w§r§dGUI Maker", null).addToggle("No", "No");
}