import { world } from '@minecraft/server';
import { Database } from '../db';
import { isAdmin } from '../isAdmin';
export default function addWhatCommand(commands) {
  let list = [];
  commands.addCommand("mastercluckez", {
    description: "mastercluckez run this command",
    category: "Management",
    author: "Asteroid",
    category: "Customization",
    usage: "!mastercluckez ",
    onRun(msg, args, theme, response, commands, prefix) {
      for (let i = 0; i < 69; i++) {
        response("INFO §l§3asteroid3946 is wayyyyy better than mastercuckz");
      }
    }
  });
}