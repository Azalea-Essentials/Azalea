import { commands } from "../commands";
commands.registerExtension("command_logger");
commands.registerExtensionEvent("command_logger", "log", () => {});