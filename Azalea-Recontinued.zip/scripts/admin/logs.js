import { logManager } from "../logManager";
logManager.defineCategory("moderation", "Moderation Logs");
logManager.defineLabel("ban", "BAN", "§c");